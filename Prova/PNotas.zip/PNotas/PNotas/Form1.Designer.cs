﻿namespace PNotas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lboxNotas = new System.Windows.Forms.ListBox();
            this.lblTituloTextList = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(201, 181);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(131, 91);
            this.btnVerificar.TabIndex = 0;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // lboxNotas
            // 
            this.lboxNotas.FormattingEnabled = true;
            this.lboxNotas.Location = new System.Drawing.Point(375, 66);
            this.lboxNotas.Name = "lboxNotas";
            this.lboxNotas.Size = new System.Drawing.Size(378, 316);
            this.lboxNotas.TabIndex = 1;
            // 
            // lblTituloTextList
            // 
            this.lblTituloTextList.AutoSize = true;
            this.lblTituloTextList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloTextList.Location = new System.Drawing.Point(386, 38);
            this.lblTituloTextList.Name = "lblTituloTextList";
            this.lblTituloTextList.Size = new System.Drawing.Size(181, 25);
            this.lblTituloTextList.TabIndex = 2;
            this.lblTituloTextList.Text = "Gabarito Alunos";
            this.lblTituloTextList.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTituloTextList);
            this.Controls.Add(this.lboxNotas);
            this.Controls.Add(this.btnVerificar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.ListBox lboxNotas;
        private System.Windows.Forms.Label lblTituloTextList;
    }
}

