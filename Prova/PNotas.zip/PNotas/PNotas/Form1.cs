﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {

            double[,] notasAlunos = new double[9, 10];

            string[] gabarito = { "D", "B", "A", "D", "B", "B", "C", "A", "C", "E" };
            string alternativa;

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    alternativa = Microsoft.VisualBasic.Interaction.InputBox("Aluno " + (i + 1).ToString() + ". Insira a alternativa assinalada na questão número " + (j + 1).ToString(), "Verificador de Respostas");
                    alternativa = alternativa.ToUpper();

                    if (alternativa == "A" || alternativa == "B" || alternativa == "C" || alternativa == "D" || alternativa == "E")
                    {
                        if (alternativa == gabarito[j])
                        {
                            lboxNotas.Items.Add("O aluno " + (i + 1) + " acertou a questão " + (j + 1).ToString() + ", era " + alternativa + ", e escolheu " + gabarito[j]);
                        }
                        else
                            lboxNotas.Items.Add("O aluno " + (i + 1) + " errou a questão " + (j + 1).ToString() + ", escolheu a alternativa " + alternativa + ", mas era " + gabarito[j]);
                    }
                    else
                    {
                        j--;
                        MessageBox.Show("Insira uma alternativa de A a E!");
                    }
                }
            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}