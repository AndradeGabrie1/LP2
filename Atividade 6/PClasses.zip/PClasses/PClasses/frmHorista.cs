﻿using System;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            // instaciando o objeto da classe horista

            // criar ou instanciar o objeto da classe Mensalista

            Horista objHorista = new Horista();

            // set

            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);

            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';
                       

            // get

            MessageBox.Show("Matrícula: " + objHorista.Matricula + "\n" + 
                "Nome: " + objHorista.NomeEmpregado + "\n" + 
                "Data Entrada: " +
                objHorista.DataEntradaEmpresa.ToShortDateString() +
                "\n" + "Salário Bruto: " + 
                objHorista.SalarioBruto().ToString("N2") + 
                "\n" + "Tempo Empresa (dias): " +
                objHorista.TempoTrabalho() + 
                "\n" + objHorista.VerificaHome());
        }
    }
}
