﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");
            }

        }

        private void BtnSomar_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) &&
               Double.TryParse(txtNum2.Text, out numero2))

            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnSubtrair_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) &&
               Double.TryParse(txtNum2.Text, out numero2))

            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");

        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) &&
               Double.TryParse(txtNum2.Text, out numero2))

            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");

        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) &&
               Double.TryParse(txtNum2.Text, out numero2) && numero2 != 0)

            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void TextBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text,out numero1))
            {
                MessageBox.Show("Número 1 inválido!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
